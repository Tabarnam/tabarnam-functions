# Project Directory Structure

```
tabarnam-functions/
├── .funcignore
├── .gitignore
├── .vscode
│   ├── extensions.json
│   ├── launch.json
│   ├── settings.json
│   └── tasks.json
├── host.json
├── local.settings.json
├── package-lock.json
├── package.json
└── src
    ├── functions
    │   └── xai.js
    └── index.js
```
